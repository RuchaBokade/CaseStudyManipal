package com.example.book.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.book.entity.BookEntity;
import com.example.book.repository.BookRepository;

@Service
public class BookService {

	@Autowired BookRepository repo;
    public List<BookEntity> getBooks()
    {
        return  repo.findAll();
    }
    public BookEntity addBookEntity(BookEntity be)
    {
        return  repo.save(be);
    }
    public BookEntity editBookEntity(BookEntity be, Integer id) 
    {
        return repo.save(be);
    }
    public BookEntity getBookEntity(Integer id) {
        return  repo.findById(id).get();
    }
    
    public void deleteBookEntity(Integer id) {
         repo.deleteById(id);
    }
	
}
