package com.example.book.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.example.book.entity.BookEntity;
import com.example.book.service.BookService;

@RestController
public class BookController {

	@Autowired BookService service;
    @GetMapping("/books")
    public List<BookEntity> getAllBookEntity()
    {
		return service.getBooks();
    }
    
    @PostMapping("/books")
    public BookEntity insertBookEntity(@RequestBody BookEntity be)
    {
        return service.addBookEntity(be);
    }
    
    @PutMapping("/books/{id}")
    public BookEntity updateBookEntity(@PathVariable("id")Integer id,@RequestBody BookEntity be)
    {
        return service.editBookEntity(be,id);
    }
    
    
    @RequestMapping(method=RequestMethod.GET,path="/books/{id}")
    public BookEntity getBookEntityDetails(@PathVariable("id")Integer id) {
        return service.getBookEntity(id);
    }
    
    @RequestMapping(method=RequestMethod.DELETE,path="/books/{id}")
    public String removeAccount(@PathVariable("id")Integer id) {
        service.deleteBookEntity(id);
        return "Book details are removed";
    }
}
